import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.junit.Test;

import lombok.extern.log4j.Log4j;


@Log4j
public class timeTest {

	
	@Test
	public void testa() {
		
		Date today = new Date();
		
		log.info(" today : " + today);
		//1594944696000
		Date dateObj = new Date(1594944696000L);
		
		log.info(dateObj);
		
		SimpleDateFormat format = new SimpleDateFormat("yy");
		log.info(format.format(today));
		
		
		
		
		
	}
	
	
}
