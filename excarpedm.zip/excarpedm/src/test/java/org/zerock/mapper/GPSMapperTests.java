package org.zerock.mapper;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.zerock.domain.GPSVO;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@Log4j
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
public class GPSMapperTests {
	
	@Setter(onMethod_ = @Autowired)
	private GPSMapper mapper; 
	
	
	
	public void insertTest() {
		
		GPSVO vo = new GPSVO();
		vo.setGps_latitude(0);
		vo.setGps_longitude(0);
		vo.setGps_tracker_no(0L);
				
		
		log.info(""+ mapper.insert(vo));
		
	}
	
	@Test
	public void getListTest() {		
		List<GPSVO> list = mapper.getList(0L);
		list.forEach(gps -> log.info(gps));
		
	}
	

}
