package org.zerock.mapper;

import java.util.List;
import java.util.stream.IntStream;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.zerock.domain.Criteria;
import org.zerock.domain.ReplyVO;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class ReplyMapperTests {

	private Long[] bnoArr = { 53L, 52L, 51L, 50L, 49L, 48L, 47L, 46L, 43L };

	@Setter(onMethod_ = @Autowired)
	private ReplyMapper mapper;

	public void testMapper() {
		log.info(mapper);
	}

	public void testCreate() {
		IntStream.rangeClosed(1, 10).forEach(i -> {
			ReplyVO vo = new ReplyVO();

			vo.setBno(bnoArr[i % 5]);
			vo.setReplyer("댓글 테스트 " + i);
			vo.setReply("replyer " + i);
			mapper.insert(vo);
		});
	}

	public void testRead() {

		Long targetRno = 5L;

		ReplyVO vo = mapper.read(targetRno);

		log.info(vo);
	}

	public void testDelete() {
		Long targetRno = 5L;

		mapper.delete(targetRno);

	}

	public void testUpdate() {

		ReplyVO vo = mapper.read(1L);

		vo.setReply("updated!");

		int count = mapper.update(vo);

		log.info("UPDATE COUNT : " + count);

	}

	@Test
	public void testList() {
		Criteria cri = new Criteria(2,10);
		
		// bnoArr[1] = 52L
		List<ReplyVO> list = mapper.getListWithPaging(cri, bnoArr[1]);
		list.forEach(reply -> log.info(reply));
	}

}
