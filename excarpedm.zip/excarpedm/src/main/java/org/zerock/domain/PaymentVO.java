package org.zerock.domain;

public class PaymentVO {

}
