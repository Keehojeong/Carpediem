package org.zerock.mapper;

import java.util.List;

import org.zerock.domain.GPSVO;

public interface GPSMapper {
	
	
	// 기기 등록
	// 기기 삭제
	public int insert(GPSVO vo);
	public List<GPSVO> getList(Long gps_tracker_no);
	
	
}
