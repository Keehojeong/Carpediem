package org.zerock.service;

import org.zerock.domain.kakaoPayApprovalVO;
import org.zerock.domain.kakaoPayReadyVO;

public interface shopService {

	
	public String kakaoPayReady();
	public kakaoPayApprovalVO kakaoPayAccept(String pg_token);
	
	
	
}
