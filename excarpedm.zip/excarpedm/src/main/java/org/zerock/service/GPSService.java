package org.zerock.service;

import java.util.List;

import org.zerock.domain.GPSVO;



public interface GPSService {
	

	// tracker 등록
	// 동물과 연결된 tracker 정보 받기
	// tracker 폐기
//	public GPSVO register();
	public int insert(GPSVO vo);
	public List<GPSVO> getList(Long gps_tracker_no);
		
	
	

}
