package org.zerock.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.zerock.domain.GPSVO;
import org.zerock.mapper.GPSMapper;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Service
@Log4j
@AllArgsConstructor
public class GPSServiceImpl implements GPSService{
	
	private GPSMapper mapper;

	
	@Override
	public int insert(GPSVO vo) {

		log.info("GPS data insert. . .");
		return mapper.insert(vo);
	}

	@Override
	public List<GPSVO> getList(Long gps_tracker_no) {
		log.info("GPS read gps. . .");
		return mapper.getList(gps_tracker_no);
	}
	
	
	

}
